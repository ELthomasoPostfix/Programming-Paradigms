runhaskell day4.hs
